<script lang="ts">
    import FooterSection from '../components/FooterSection.svelte';
</script>

<svelte:head>
    <title>Terms of Service - Penak.online</title>
</svelte:head>

<div class="min-h-screen bg-black text-white pt-32 pb-20">
    <div class="container max-w-4xl">
        <h1 class="text-4xl md:text-5xl font-black mb-8 font-['Playfair_Display']">Terms of Service</h1>
        <p class="text-white/60 mb-12 italic text-sm">Terakhir diperbarui: 16 Februari 2026</p>

        <div class="space-y-8 text-lg leading-relaxed">
            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">1. Penggunaan Layanan</h2>
                <p class="text-white/80">Dengan mengakses Penak.online, Anda setuju untuk terikat oleh Syarat dan Ketentuan ini. Anda setuju untuk menggunakan layanan kami hanya untuk tujuan yang sah dan tidak melanggar hukum yang berlaku di Indonesia.</p>
            </section>

            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">2. Akun Pengguna</h2>
                <p class="text-white/80">Anda bertanggung jawab untuk menjaga kerahasiaan akun dan kata sandi Anda. Semua aktivitas yang terjadi di bawah akun Anda adalah tanggung jawab Anda sepenuhnya.</p>
            </section>

            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">3. Kekayaan Intelektual</h2>
                <p class="text-white/80">Semua konten di situs ini, termasuk namun tidak terbatas pada teks, grafis, logo, dan kode, adalah milik Penak.online dan dilindungi oleh undang-undang hak cipta.</p>
            </section>

            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">4. Pembatasan Tanggung Jawab</h2>
                <p class="text-white/80">Penak.online tidak bertanggung jawab atas kerugian tidak langsung, insidental, atau konsekuensial yang timbul dari penggunaan atau ketidakmampuan untuk menggunakan layanan kami.</p>
            </section>

            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">5. Perubahan Ketentuan</h2>
                <p class="text-white/80">Kami berhak mengubah syarat dan ketentuan ini sewaktu-waktu tanpa pemberitahuan sebelumnya. Perubahan akan berlaku segera setelah dipublikasikan di halaman ini.</p>
            </section>
        </div>
        
        <div class="mt-16 pt-8 border-t border-white/10">
            <a href="/" class="text-yellow-200 font-bold hover:text-yellow-100 transition-colors">← Kembali ke Beranda</a>
        </div>
    </div>
</div>

<FooterSection />
