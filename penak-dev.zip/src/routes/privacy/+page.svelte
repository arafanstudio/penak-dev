<script lang="ts">
    import FooterSection from '../components/FooterSection.svelte';
</script>

<svelte:head>
    <title>Privacy Policy - Penak.online</title>
</svelte:head>

<div class="min-h-screen bg-black text-white pt-32 pb-20">
    <div class="container max-w-4xl">
        <h1 class="text-4xl md:text-5xl font-black mb-8 font-['Playfair_Display']">Privacy Policy</h1>
        <p class="text-white/60 mb-12 italic text-sm">Terakhir diperbarui: 16 Februari 2026</p>

        <div class="space-y-8 text-lg leading-relaxed">
            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">1. Pendahuluan</h2>
                <p class="text-white/80">Di Penak.online, kami menghargai privasi Anda. Kebijakan Privasi ini menjelaskan bagaimana kami mengumpulkan, menggunakan, dan melindungi informasi pribadi Anda saat Anda menggunakan layanan kami.</p>
            </section>

            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">2. Informasi yang Kami Kumpulkan</h2>
                <p class="text-white/80">Kami mengumpulkan informasi yang Anda berikan secara langsung, seperti nama dan alamat email saat mendaftar, serta data penggunaan otomatis melalui cookie untuk meningkatkan pengalaman pengguna.</p>
            </section>

            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">3. Penggunaan Informasi</h2>
                <p class="text-white/80">Informasi Anda digunakan untuk memproses pesanan, memberikan dukungan pelanggan, dan mengirimkan pembaruan terkait layanan kami.</p>
            </section>

            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">4. Keamanan Data</h2>
                <p class="text-white/80">Kami menerapkan langkah-langkah keamanan teknis untuk melindungi data Anda dari akses yang tidak sah.</p>
            </section>

            <section>
                <h2 class="text-2xl font-bold text-yellow-200 mb-4 font-['Playfair_Display']">5. Hak Anda</h2>
                <p class="text-white/80">Anda berhak untuk mengakses, memperbaiki, atau menghapus informasi pribadi Anda kapan saja dengan menghubungi kami.</p>
            </section>
        </div>
        
        <div class="mt-16 pt-8 border-t border-white/10">
            <a href="/" class="text-yellow-200 font-bold hover:text-yellow-100 transition-colors">← Kembali ke Beranda</a>
        </div>
    </div>
</div>

<FooterSection />
